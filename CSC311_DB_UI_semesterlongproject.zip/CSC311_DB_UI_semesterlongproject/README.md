**_JavaFX Database Application for CSC311 Project_**

**Table of Contents**

1. About the Project
2. Features
3. Usage
4. Keyboard Shortcuts


**About the Project**\
This project is a JavaFX-based graphical user interface (GUI) application for managing a user database. The application connects to a MySQL database hosted on Azure and offers functionalities such as adding, editing, deleting, and searching user records. Users can also upload profile images and import/export data via CSV files.

**Features** 
* User Management:Add, edit, delete, and search user records.
* Manage user details including name, department, major, email, and optional profile image.
* File Operations:Import data from CSV files.
* Export user data to CSV files.
* Azure Integration:Upload profile images to Azure Blob Storage.
* Theme Customization:Switch between light and dark themes.
* Keyboard Shortcuts:Perform common operations quickly using shortcuts.
* 
**Usage**\
Launching the Application\
Start the application from the generated JAR file or by running the MainApplication class.\
Adding a Record\
Fill out the form fields (first name, last name, department, major, email, and optional image URL).\
Click Add or press Ctrl+A to save the record.\
Editing a Record\
Select a record from the table
Modify the details in the form fields.
Click Edit or press Ctrl+E to update the record.\
Deleting a Record\
Select a record from the table.
Click Delete or press Ctrl+D.\
Import/Export CSV\
Import: Click the Import CSV button and select a file.\
Export: Click the Export CSV button to save the data.\
Logging In\
Default credentials:
Username: h
Password: h.

**Keyboard Shortcuts**\
Shortcut\
Ctrl+E	Edit selected record\
Ctrl+D	Delete selected record\
Ctrl+R	Clear form fields\
Ctrl+C	Copy record details\